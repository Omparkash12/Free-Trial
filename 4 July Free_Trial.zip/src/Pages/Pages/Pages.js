import React from 'react';
import FreeTrial from '../FreeTrial/FreeTrial';
import '../../App.css'


const Pages = () => {
  return (
    <div>
        <FreeTrial />
    </div>
  )
}

export default Pages